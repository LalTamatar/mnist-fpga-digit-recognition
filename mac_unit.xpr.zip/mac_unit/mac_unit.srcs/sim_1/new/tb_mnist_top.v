`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11.10.2026 20:22:52
// Design Name: 
// Module Name: tb_mnist_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



`timescale 1ns / 1ps

module tb_mnist_top;

    reg clk = 0;
    reg rst = 1;
    reg start = 0;

    wire busy;
    wire done;
    wire [3:0] predicted_digit;

    mnist_top dut (
        .clk(clk),
        .rst(rst),
        .start(start),
        .busy(busy),
        .done(done),
        .predicted_digit(predicted_digit)
    );

    always #5 clk = ~clk;

    initial begin
        $display("Starting real MNIST inference test...");

        repeat (4) @(negedge clk);
        rst = 0;

        // Pulse start for one clock cycle.
        @(negedge clk);
        start = 1;
        @(negedge clk);
        start = 0;

        // Allow time for all three Dense layers to finish.
        wait(done == 1'b1);

        $display("------------------------------------");
        $display("Expected digit : 7");
        $display("Predicted digit: %0d", predicted_digit);
        $display("------------------------------------");

        if (predicted_digit == 4'd7)
            $display("PASS: Prediction matches expected digit.");
        else
            $display("CHECK: Prediction differs from expected digit.");

        repeat (5) @(negedge clk);
        $finish;
    end

    initial begin
        // 2 ms simulated time; enough for this serial implementation.
        #2000000;
        $display("ERROR: Simulation timeout.");
        $finish;
    end

endmodule

