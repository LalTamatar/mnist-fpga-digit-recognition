
module mac_unit (
    input wire clk,
    input wire rst,
    input wire clear,
    input wire mac_en,

    input wire signed [15:0] x,
    input wire signed [15:0] w,
    input wire signed [15:0] bias,

    output reg signed [39:0] acc,
    output wire signed [15:0] result,
    output reg done
);

    wire signed [31:0] product;
    wire signed [39:0] product_ext;
    wire signed [39:0] acc_next;
    wire signed [39:0] rounded;

    // Q8 x Q8 = Q16 product.
    assign product = x * w;

    // Sign-extend the product to 40 bits.
    assign product_ext = {{8{product[31]}}, product};

    assign acc_next = acc + product_ext;

    // Round to nearest, ties away from zero.
    assign rounded = (acc_next >= 0)
                   ? acc_next + 40'sd128
                   : acc_next - 40'sd128;

    // Convert Q16 accumulator to Q8 and saturate.
   
    wire signed [39:0] shifted;

    assign shifted = acc >>> 8;

    assign result = (shifted > 40'sd32767)
                   ? 16'sh7fff
                   : (shifted < -40'sd32768)
                   ? 16'sh8000
                   : shifted[15:0];

    always @(posedge clk) begin
        if (rst) begin
            acc  <= 40'sd0;
            done <= 1'b0;
        end else begin
            done <= 1'b0;

            if (clear) begin
                // Load Q8 bias into Q16 accumulator scale.
                acc <= {{8{bias[15]}}, bias, 8'b0};
            end else if (mac_en) begin
                acc <= acc_next;
            end
        end
    end

endmodule


`timescale 1ns / 1ps

module tb_mac_unit;

    reg clk;
    reg rst;
    reg clear;
    reg mac_en;

    reg signed [15:0] x;
    reg signed [15:0] w;
    reg signed [15:0] bias;

    wire signed [39:0] acc;
    wire signed [15:0] result;
    wire done;

    mac_unit dut (
        .clk(clk),
        .rst(rst),
        .clear(clear),
        .mac_en(mac_en),
        .x(x),
        .w(w),
        .bias(bias),
        .acc(acc),
        .result(result),
        .done(done)
    );

    // 10 ns clock period.
    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst = 1;
        clear = 0;
        mac_en = 0;
        x = 0;
        w = 0;
        bias = 0;

        // Reset the DUT.
        repeat (2) @(negedge clk);
        rst = 0;

        // x = 2.0, w = 1.5, bias = 1.0 (Q8).
        x = 16'sd512;
        w = 16'sd384;
        bias = 16'sd256;

        // Load bias.
        @(negedge clk);
        clear = 1;

        @(negedge clk);
        clear = 0;

        // Accumulate x * w.
        mac_en = 1;

        @(negedge clk);
        mac_en = 0;

        #1;

        $display("Accumulator = %0d", acc);
        $display("Result      = %0d", result);
        $display("Result hex  = %04h", result);

        if (result === 16'sd1024) begin
            $display("PASS: Expected result 4.0.");
        end else begin
            $display("FAIL: Expected 1024, got %0d", result);
            $fatal(1);
        end

        $finish;
    end

endmodule
